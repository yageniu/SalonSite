import { getLogedInUser, logout } from "../utils/auth/authenticate";
import { useNavigate } from "react-router-dom";

function LogOut() {
  const navigate = useNavigate();
  async function onLogOut() {
    try {
      await logout();
      navigate("/");
    } catch (error) {
      return error.message;
      // console.log(error);
    }
  }
  const logedInUser = getLogedInUser();
  return (
    <>
    <div className = "logout">

      <p className = "logOutText">{logedInUser.data.name} </p>
      {/* <p className = "logOutText"><b>User E-mail:</b> {logedInUser.data.email}</p> */}
      <button className="logoutBtn" onClick={onLogOut}>
        LogOut
      </button>
    </div>
    </>
  );
}

export default LogOut;
