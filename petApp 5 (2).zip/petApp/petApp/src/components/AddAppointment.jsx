import Form from "react-bootstrap/Form";
import { useForm, Controller } from "react-hook-form";
import { postData } from "../services/post";
import { updateData } from "../services/update";
import { useEffect } from "react";
import Rating from "@mui/material/Rating";
import StarIcon from '@mui/icons-material/Star';
import FavoriteIcon from '@mui/icons-material/Favorite';

function AddAppointment({ update, setUpdate, pet, setEdit, hideForm }) {
  const currDate = new Date().toJSON().slice(0, 10);
  const {
    register,
    reset,
    handleSubmit,
    formState: { errors },
    setValue,
    control
  } = useForm({
    defaultValues: {
      // id,
      name: "",
      owner: "",
      date: "",
      time: "",
      note: "",
      rating: "",
    },
  }); 
  const forSubmitHandler = async (data) => {
    try {
      if (pet) {
        await updateData(pet._id, data);
        setEdit(false);
      } else {
        await postData({ ...data });
        hideForm()
      }
      const selectedDate = new Date(data.date + "T" + data.time);
      if (selectedDate < new Date()) {
        alert(
          "Selected date and time cannot be earlier than the current date and time."
        );
        return;
      }
      setUpdate((update) => update + 1);
      reset();
    } catch (error) {
      console.log(error);
    }
  };


  useEffect(() => {
    if (pet) {
      setValue("name", pet.name, { shouldValidate: true });
      setValue("owner", pet.owner, { shouldValidate: true });
      setValue("date", pet.date, { shouldValidate: true });
      setValue("time", pet.time, { shouldValidate: true });
      setValue("note", pet.note, { shouldValidate: true });
    }
  }, [pet]);

  return (
    <Form
      className="w-75 m-auto mt-3 formspace"
      onSubmit={handleSubmit(forSubmitHandler)}
    >
      <Form.Group className="mb-3">
        <Form.Label htmlFor="petName">Pet Name</Form.Label>
        <Form.Control
          type="text"
          rows={3}
          id="petName"
          placeholder="Pet's Name"
          className = "formspace"
          {...register("name", { required: "Name is required" })}
        />
      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label htmlFor="petOwner">Pet Owner</Form.Label>
        <Form.Control
          type="text"
          rows={3}
          id="petOwner"
          placeholder="Owner's Name"
          {...register("owner", { required: "Owner's Name is required" })}
        />
      </Form.Group>
      <Form.Group className="mb-3">
        <div className="row">
          <div className="col">
            <Form.Label>Date</Form.Label>
            <Form.Control
              type="date"
              id="appointmentDate"
              {...register("date", {
                required: "Date is required",
                min: currDate,
              })}
            />
          </div>
          <div className="col">
            <Form.Label>Time</Form.Label>
            <Form.Control
              type="time"
              id="appointmentTime"
              {...register("time", { required: "Time is required" })}
            />
          </div>
        </div>

      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label htmlFor="appointmentNote">Apt. Notes</Form.Label>
        <Form.Control
          as="textarea"
          rows={3}
          id="appointmentNote"
          placeholder="Appointment Notes"
          {...register("note")}
        />
      </Form.Group>
      <div className="form-rating">
              <label >Rate your experience : </label>
              <Controller
                name="rating"
                control={control}
                defaultValue={0}
                render={({ field }) => (
                  <Rating
                  value={Number(field.value)}
                  onChange={(newValue) => {
                    field.onChange(newValue);
                  }}
                  icon={<StarIcon className="blue-star-icon" />}
                />
                )}
              />
            </div>

     <div className="d-flex justify-content-end">
    <button className="submit-button btnspace">Add Appointment</button>
</div>
    </Form>
  );
}

export default AddAppointment;
