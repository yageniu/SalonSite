import React, { useState } from 'react';
import LogOut from './LogOut'; //

function Header() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);



  return (
    <div className="header">
      <p>🐕 Pets Medicare 🐈</p>
      {isLoggedIn && <LogOut />} 

    </div>
  );
}

export default Header;