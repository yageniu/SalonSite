import { useForm } from "react-hook-form";
import { useState } from "react";
import { login } from "../utils/auth/authenticate";
import { useNavigate } from "react-router-dom";

import Form from "react-bootstrap/Form";
import { Link } from "react-router-dom";
import {
  FormErrorMessage,
  FormLabel,
  FormControl,
  Input,
  Button,
} from "@chakra-ui/react";

function LoginForm({ setUpdate }) {
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const {
    handleSubmit,
    register,
    formState: { errors, isSubmitting },
  } = useForm();

  async function onSubmit(values) {
    try {
      await login(values);
      setUpdate((prev) => prev + 1);
      navigate("/appointments");
    } catch (error) {
      setError(error.response.data.message);
    }
  }

  return (
    <div className="formImage">
      <div>
        <h5 className="logintop">Please login to your account to add or see your appointments</h5>
      </div>
      <div className="centered-form">
        <Form onSubmit={handleSubmit(onSubmit)}>
          <Form.Group className="mb-1" controlId="formGroupEmail">
            <Form.Label></Form.Label>
            <Form.Control
              isInvalid={errors.name}
              type="email"
              placeholder="Enter your email"
              {...register("email", {
                required: "Email adress is required",
                pattern: {
                  value: /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/,
                  message: "Invalid email address",
                },
              })}
              className="wider-input"
            />
            <FormErrorMessage>
              {errors.name && errors.name.message}
            </FormErrorMessage>
          </Form.Group>
          <Form.Group className="mb-1" controlId="formGroupPassword">
            <Form.Label></Form.Label>
            <Form.Control
              type="password"
              placeholder="Password"
              {...register("password", {
                required: "Password is required",
                minLength: {
                  value: 8,
                  message: "Minimum length should be 8 symbols",
                },
              })}
              className="wider-input"
            />

            <FormErrorMessage>
              {errors.name && errors.name.message}
            </FormErrorMessage>

            <Button
              className="submit-button mt-3"
              isLoading={isSubmitting}
              type="submit"
            >
              Login
            </Button>
          </Form.Group>
        </Form>
      </div>
      <div>
        <h6 className="loginbottom">
          If you do not have an account, please{" "}
          <Link to="http://localhost:5173/signup">register here!</Link>
        </h6>
      </div>
    </div>
  );
}

export default LoginForm;
