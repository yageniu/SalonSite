import { Form } from "react-bootstrap";

function Search({ setQuery }) {
  return (
    <Form className="pt-3 w-75 mx-auto formspace">
      <Form.Group controlId="formBasicSearch">
        <Form.Control
          type="text"
          placeholder="What are you looking for?"
          onChange={(e) => setQuery(e.target.value)}
        />
      </Form.Group>
    </Form>
  );
}

export default Search;
