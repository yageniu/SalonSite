import React, { useState, useEffect } from 'react';
import Card from "react-bootstrap/Card";
import { deleteData } from "../services/delete";
import { GoTrash } from "react-icons/go";
import { CiEdit } from "react-icons/ci";
import AddAppointment from "./AddAppointment";
import Rating from "@mui/material/Rating";
import classNames from 'classnames';
import axios from 'axios';

function AppointmentInfo({ pet, setPets, update, setUpdate }) {
  const [edit, setEdit] = useState(false);
  const { _id, name, owner, date, time, note, rating } = pet;
  const [deleteError, setDeleteError] = useState(null);
  const [isSmallScreen, setIsSmallScreen] = useState(window.innerWidth <= 576);
  const [isApproved, setIsApproved] = useState(pet.status);
  const [userRole, setUserRole] = useState("");
  const handleApproved = async () => {
    try {
      const token = localStorage.getItem("user");
      console.log(token);
      
      await axios.patch(
        `http://localhost:3003/api/v1/appointments/status/${_id}`,
        {},
        {
          headers: {
            Authorization: "Bearer " + token,
          },
        }
      );

      setIsApproved((prev) => !prev);
    } catch (error) {
      console.log(error);

    }
  };
  useEffect(() => {
    let userRole = JSON.parse(localStorage.getItem("user")).data.role;
    console.log(userRole);
    setUserRole(userRole);
  }, []);

  useEffect(() => {
    const handleResize = () => {
      setIsSmallScreen(window.innerWidth <= 1043);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const handleDelete = async (id) => {
    await deleteData(id);
    setUpdate((update) => update + 1);
  };

  return (
    <Card className={classNames('d-flex', 'flex-row', 'align-items-center', 'mt-4', 'mx-auto', 'rounded-2', 'card-container', {'w-50': !isSmallScreen, 'w-75': isSmallScreen})}>
    <button className="rounded-2 border-0 ms-3" onClick={() => { setEdit((edit) => !edit) }}>
      <CiEdit className="CiEdit" />
    </button>
    <button onClick={() => handleDelete(_id)} className="rounded-2 border-0 ms-3">
      <GoTrash className="GoTrash" />
    </button>
    <Card.Body className="card">
      <Card.Title>{name}</Card.Title>
      <Card.Subtitle className="mb-2 text-muted">
        Owner: {owner}
      </Card.Subtitle>
      <Card.Text>{note}</Card.Text>
    </Card.Body>
    <div className="card">
      <p className="me-3">
        {date} {time}
      </p>
    </div>
    <Rating className="rating" value={rating} />
    <div className="pet-card-status">
      {isApproved ? (
        <InputGroup.Checkbox aria-label="Pending" />
      ) : (
        userRole==="admin" && <button className= "acceptBtn" onClick={handleApproved}>Accept</button>
      )}
    </div>
    {edit && <AddAppointment pet={pet} setEdit={setEdit} update={update} setUpdate={setUpdate} />}
    {deleteError && <p style={{ color: "red" }}>{deleteError}</p>}
  </Card>
  );
}

export default AppointmentInfo;