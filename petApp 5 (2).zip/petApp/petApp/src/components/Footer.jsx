function Footer() {
  return (
    <div className="footer">
      <p>
        Baltas.Vilkas © 2024
      </p>
    </div>
  );
}

export default Footer;
