import { useEffect } from "react";
import { getLogedInUser } from "../utils/auth/authenticate";
import { useNavigate } from "react-router-dom";


function ProtectedRoute({children}) { // paims App.js viska,kas yra viduje ProtectedRoute viduje
    const navigate = useNavigate();
    const logedInUser = getLogedInUser();
    useEffect (() => {
        if (!logedInUser) {
           return navigate("/");
        }

    }, []) // priklausomybe nuo logedInUser, pasitikrinam ar yra user, ar ne tada nukreipiam i login
    return (  
     <>{children}</>
    );
}

export default ProtectedRoute;