import AppointmentInfo from "./AppointmentInfo";
import { useState, useEffect } from "react";
import { getAllData } from "./../services/get";
import Pagination from "@mui/material/Pagination";
import PaginationItem from "@mui/material/PaginationItem";
import Stack from "@mui/material/Stack";


function AppointmentList({ onEdit, onDelete, query, update, setUpdate }) {
  const [sortCriteria, setSortCriteria] = useState("date");
  const [pets, setPets] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [resultsPerPage, setResultsPerPage] = useState(5);
  
  useEffect(() => {
    setSortCriteria("date");
  }, []);

  const handleSortChange = (event) => {
    setSortCriteria(event.target.value);
  };

  const fetchData = async () => {
    const response = await getAllData();
    console.log(response);
    setPets(response.data.appointments);
  };

  useEffect(() => {
    fetchData();
  }, [update]);

  const sortedPets = [...pets].sort((a, b) => {
    if (sortCriteria === "date") {
      return new Date(a.date) - new Date(b.date);
    } else if (sortCriteria === "name") {
      return a.name.localeCompare(b.name);
    } else {
      return a.owner.localeCompare(b.owner);
    }
  });

  const filteredPets = sortedPets.filter(
    (pet) =>
      pet.name.toLowerCase().includes(query.toLowerCase()) ||
      pet.owner.toLowerCase().includes(query.toLowerCase()) ||
      pet.note.toLowerCase().includes(query.toLowerCase())
  );

  const totalPages = Math.ceil(filteredPets.length / resultsPerPage);
  const startIndex = (currentPage - 1) * resultsPerPage;
  const endIndex = Math.min(startIndex + resultsPerPage, filteredPets.length);
  const currentPagePets = filteredPets.slice(startIndex, endIndex);

  return (
    <>
      <div>
   
        <div className="sorting">
          <label className="lbl" htmlFor="sortCriteria">
            Sort by:
          </label>
          <select
            className="selectBorder transparentBackground"
            id="sortCriteria"
            value={sortCriteria}
            onChange={handleSortChange}
          >
            <option value="date">Date</option>
            <option value="name">Pet Name</option>
            <option value="owner">Owner</option>
          </select>
          <select
            className="selectBorder transparentBackground pagination"
            value={resultsPerPage}
            onChange={(e) => {
              setCurrentPage(1);
              setResultsPerPage(parseInt(e.target.value, 10));
            }}
          >
            <option value="3">3 per page</option>
            <option value="5">5 per page</option>
            <option value="10">10 per page</option>
            <option value={filteredPets.length}>All</option>
          </select>
        </div>
        {currentPagePets.map((pet) => (
          <AppointmentInfo
            pet={pet}
            onEdit={onEdit}
            onDelete={onDelete}
            setPets={setPets}
            key={pet._id}
            update={update}
            setUpdate={setUpdate}
          />
        ))}
      </div>
      <Stack spacing={2} sx={{ display: "flex", justifyContent: "center", margin: "3rem" }}>
        <Pagination
          count={totalPages}
          page={currentPage}
          onChange={(event, page) => setCurrentPage(page)}
          renderItem={(item) => (
            <PaginationItem
              {...item}
              sx={{
                "&.Mui-selected": {
                  backgroundColor: "#0a73bf",
                  color: "#ffffff",
                  borderRadius: "50%",
                  padding: "5px 10px",
                },
              }}
            />
          )}
          sx={{
            display: "flex",
            justifyContent: "center",
          }}
        />
      </Stack>
    </>
  );
}

export default AppointmentList;