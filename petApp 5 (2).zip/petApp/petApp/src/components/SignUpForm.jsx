import { useForm } from "react-hook-form";
import { useState } from "react"; // state'o reikes errorui sugaudyti sikart
import { signup } from "./../utils/auth/authenticate";
import { useNavigate } from "react-router-dom";
import {authenticate} from "../utils/auth/authenticate";
import Container from "react-bootstrap/Container";

import Form from "react-bootstrap/Form";
import {Link} from "react-router-dom";
import {
  FormErrorMessage,
  FormLabel,
  FormControl,
  Input,
  Button,
} from "@chakra-ui/react";

function SignUpForm() {
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const {
    handleSubmit,
    register,
    watch,
    formState: { errors, isSubmitting },
  } = useForm(); // cia form hook'sas

  async function onSubmit(values) {
    console.log(values);
    try {
      await signup(values);
      navigate("/appointments"); // tai reiskia, kai padarai login, pereik i appointments route (page)
    } catch (error) {
      setError(error.response.data.message);
    }
  }

  return (
    
    <div className = "formImageSign">
    <div>
      <h5 className = "signuptop">Please create an account to add or see Your appointments</h5>
    </div>
  
    <div className="centered-form">
    <Form onSubmit={handleSubmit(onSubmit)}>
  <Form.Group className="mb-1" controlId="formGroupUsername">
    <Form.Label></Form.Label>
    <Form.Control
      isInvalid={errors.name}
      type="text"
      placeholder="Enter your username"
      {...register("name", {
        required: "Username is required",
      })}
      className="wider-input"
    />
    <FormErrorMessage>
      {errors.name && errors.name.message}
    </FormErrorMessage>
  </Form.Group>
  <Form.Group className="mb-1" controlId="formGroupEmail">
    <Form.Label></Form.Label>
    <Form.Control
      isInvalid={errors.email}
      type="email"
      placeholder="Enter your email"
      {...register("email", {
        required: "Email address is required",
        pattern: {
          value: /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/,
          message: "Invalid email address",
        },
      })}
      className="wider-input"
    />
    <FormErrorMessage>
      {errors.email && errors.email.message}
    </FormErrorMessage>
  </Form.Group>
  <Form.Group className="mb-1" controlId="formGroupPassword">
    <Form.Label></Form.Label>
    <Form.Control
      type="password"
      placeholder="Password"
      {...register("password", {
        required: "Password is required",
        minLength: {
          value: 8,
          message: "Minimum length should be 8 symbols",
        },
      })}
      className="wider-input"
    />
    <FormErrorMessage>
      {errors.password && errors.password.message}
    </FormErrorMessage>
  </Form.Group>
  <Form.Group className="mb-1" controlId="formGroupConfirmPassword">
    <Form.Label></Form.Label>
    <Form.Control
      type="password"
      placeholder="Confirm Password"
      {...register("passwordConfirm", {
        required: "Please confirm your password",
        validate: (value) =>
          value === watch("password") || "The passwords do not match",
      })}
      className="wider-input"
    />
    <FormErrorMessage>
      {errors.passwordConfirm && errors.passwordConfirm.message}
    </FormErrorMessage>
  </Form.Group>
  <Button className="submit-button" isLoading={isSubmitting} type="submit">
    Sign Up
  </Button>
</Form>
    </div>
    <h6 className="signupbottom">If you have an account, please <Link to="http://localhost:5173">login!</Link></h6>
    </div>

  );
}

export default SignUpForm;
