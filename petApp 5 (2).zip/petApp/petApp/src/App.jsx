import { useState, useEffect } from "react";
import AddAppointment from "./components/AddAppointment";
import Container from "react-bootstrap/Container";

import Header from "./components/Header";
import Footer from "./components/Footer";
import AppointmentList from "./components/AppointmentList";
import { deleteData } from "./services/delete";
import Search from "./components/Search";

import LoginForm from "./components/LoginForm";
import ProtectedRoute from "./components/ProtectedRoute";
import { Routes, Route } from "react-router-dom";
import LogOut from "./components/LogOut";
import SingUpForm from "./components/SignUpForm";

function App() {
  const [showForm, setShowForm] = useState(false);
  const [update, setUpdate] = useState(0);
  const [deleteError, setDeleteError] = useState(null);
  const [query, setQuery] = useState("");
  // const [sortBy, setSortBy] = useState("");

  function handleShowForm() {
    setShowForm((show) => !show);
  }

  async function handleDeleteAppointment(id) {
    await deleteData(id, setPets);
    setDeleteError(null);
    const success = await deleteData(id);
    if (success) {
      setPets(pets.filter((pet) => pet.id !== id));
      setDeleteError(null);
    } else {
      setDeleteError("Failed to delete the appointment. Please try again");
    }
  }

  return (
    <div className="app-container">
      <Header />
      <div className="bodycolor">
        <Routes>
          <Route index element={<LoginForm setUpdate={setUpdate} />} />
          <Route path="/signup" element={<SingUpForm />} />
          <Route
            path="/appointments"
            element={
              // <ProtectedRoute>
              <div className="content">
                   <LogOut className = "logout"/>
                <Container>
                  <button
                    onClick={handleShowForm}
                    className="appBtn w-100 rounded-2 border-1 border-light"
                  >
                    {showForm ? "❎ Cancel" : "✅ Add Appointment"}
                  </button>
                  {showForm && (
                    <AddAppointment
                      update={update}
                      setUpdate={setUpdate}
                      hideForm={handleShowForm}
                    />
                  )}
                </Container>

                <Container className="d-flex">
                  <Search setQuery={setQuery} />
                </Container>

                <AppointmentList
                  onDelete={handleDeleteAppointment}
                  query={query}
                  update={update}
                  setUpdate={setUpdate}
                />
        
              </div>
              // </ProtectedRoute>
            }
          ></Route>
        </Routes>
      </div>
      <Footer />
    </div>
  );
}

export default App;
