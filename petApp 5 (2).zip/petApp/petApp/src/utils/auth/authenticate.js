import axios from "axios";

// cia rasysim login funkcija kai paspaudzia submit
export const login = async (values) => {
  // async nes axios grazina promise
  const response = await axios.post(
    "http://localhost:3003/api/v1/users/login",
    values
  );
  // console.log(response.data);
  localStorage.setItem("user", JSON.stringify(response.data)); // localStorage duomenys saugomi JSON'u todel reikes "vartyti"
};
export const signup = async (values) => {
  const response = await axios.post(
    "http://localhost:3003/api/v1/users/signup",
    values
    
  ); 
  console.log(response.data);

  localStorage.setItem("user", JSON.stringify(response.data));
}

//sita funkcija is locaslStorage nusiskaitome duomenis
export const getLogedInUser = () => {
  const logedInUser = JSON.parse(localStorage.getItem("user")); // imam is virsutines funkcijos kur locarStorage.SetItem("user", JSON.stringify(response.data))
  // ateina kaip stringas, reikia pasiversti JSON formatu, todel rasome JSON.parse

  if (!logedInUser) {
    return null;
  }
  return logedInUser;
};

export const authenticate = () => {
  const logedInUser = getLogedInUser();
  const token = logedInUser ? logedInUser.token : null;

  if (token) {
    axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;
  } else {
    delete axios.defaults.headers.common["Authorization"];
  }
};

export const logout = () => {
  localStorage.removeItem("user");
}
