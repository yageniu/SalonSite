import axios from "axios";
import { authenticate } from "../utils/auth/authenticate";
const API_URL = import.meta.env.VITE_API_URL;

export const updateData = async (id, data) => {
  authenticate();
    const response = await axios.patch(`${API_URL}/${id}`, data);
    return response.data;
  };
  