import axios from "axios";
import { getOne } from "./get";
import { getAllData } from "./get";
import { authenticate } from "../utils/auth/authenticate"

const API_URL = import.meta.env.VITE_API_URL;

export const deleteData = async (id) => {
  authenticate();
  const { name } = await getOne(id);

  const confirmed = window.confirm(
    `Are you sure you want to delete ${name} appointment? This cannot be undone!`
  );

  if (!confirmed) return;

  await axios.delete(`${API_URL}/${id}`);

};
