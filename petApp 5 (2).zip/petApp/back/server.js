const mongoose = require("mongoose");

const app = require("./app");

const dotenv = require("dotenv").config(); 
const port = process.env.PORT || 3003;
const dbURL = process.env.DATABASE_URL; //

async function main() {
  await mongoose.connect(dbURL);
  console.log("Connected to database");
}
main().catch((err) => console.log(err)); 


app.listen(port, () => {
  console.log(`App running on port ${port}`);
});




