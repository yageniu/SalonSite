const User = require("../models/userModel");
const jwt = require("jsonwebtoken");
const { promisify } = require("util"); // nesinchriniius procesus pavercia sinchroniniais

const signToken = (id) => {
  // si funkcija skirta gauti token'a
  const token = jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN, // kiek laiko galioja JWT tokenas, del saugumo
  });
  return token;
};

const sendCookie = (token, res) => {
  const cookieOptions = {
    expires: new Date(
      Date.now() + process.env.JWT_COOKIE_EXPIRES_IN * 24 * 60 * 60 * 1000 // taip verciama milisekundemis VISADA
    ),
    httpOnly: true,
  };

  res.cookie("jwt", token, cookieOptions);
};

// SIGN UP
exports.signup = async (req, res, next) => {
  try {
    const newUser = await User.create({
      // issikonstruojam re.body, ne tiesiog rasome req.body tam, kad butu irasyti tik duomenys, kurie privalo buti irasyti, o ne bet kas
      name: req.body.name,
      email: req.body.email,
      password: req.body.password, // cia paswordas ateis jau uzhash'intas, kur naudojame userSchema.pre
      passwordConfirm: req.body.passwordConfirm,
      role: req.body.role,  // sita ijungiam, kai reikia ivest useri admin teisem, bet jei palieka, tada bet kas per postman gales prisijungti admin teisem
    });

    // issiunciam tokena
    const token = signToken(newUser._id);

    sendCookie(token, res);

    newUser.password = undefined;

    res.status(201).json({
      status: "success",
      token,
      data: newUser,
    });
  } catch (error) {
    res.status(404).json({
      status: "fail",
      message: error.message,
    });
  }
};

// LOGIN

exports.login = async (req, res, next) => {
  try {
    // pasiimam is bodzio duomenis
    const { email, password } = req.body;
    // patikrinam ar duomenys yra
    if (!email || !password) {
      // metodas, kuris tikrina ar yra emailas ir paswordas
      return next(new Error("Please provide email and password"));
    }
    const user = await User.findOne({ email }).select("+password");
    if (!user || !(await user.correctPassword(password, user.password))) {
      // pirmas yra candidate password, antras aetina is DB
      return next(new Error("Incorrect email or password")); // SVARBU return turi buti, kad nebutu vykdoma toliau funkcija, jei pokyciu nera, sitas grazina errora html formatu
    }
    const token = signToken(user._id);
    sendCookie(token, res);
    user.password = undefined;

    res.status(200).json({
      status: "success",
      token,
      data: user,
    });
  } catch (error) {
    res.status(404).json({
      status: "fail",
      message: error.message,
    });
  }
};

exports.protect = async (req, res, next) => {
  try {
    // 1. PATIKRINSIME AR ATSISIUNTE TOKEN
    let token;

    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith("Bearer")
    ) {
      token = req.headers.authorization.split(" ")[1];

      if (!token) {
        return next(new Error("You are not logged in! Please log in!"));
      }
    }
    // 2. PATIKRINSIME AR TOKEN VALIDUS
    const decoded = await promisify(jwt.verify)(token, process.env.JWT_SECRET);
    console.log(decoded);

    const existingUser = await User.findById(decoded.id); // prie requesto prikabinam useri
    req.user = existingUser; //req yra objektas
    next();
    // 3. AR USERIS VIS DAR YRA
    // 4. PATIKRINTI AR USERIS NEPAKEITE PASSWORD PO TO, KAI TOKEN BUVO SUGENERUOTAS
  } catch (error) {
    res.status(401).json({
      status: "fail",
      message: error.message,
    });
  }
};

exports.allowTo = (...roles) => {
  // cia paimame roles, kurias norime naudoti, o jis yra nurodytos bookRouter apacioje, kuriame nurodome ka norime naudoti
  return async (req, res, next) => {
    try {
      if (!roles.includes(req.user.role)) {
        return next(
          // labai svarbu parasyti return. Logika kokia, kad pirma reikia galvoti, kas bus, jei ne, o tada tiktai kas bus, jei taip (next() tada rasome)
          new Error("You do not have permission to perform this action!")
        );
      }
      next();
    } catch (error) {
      res.status(403).json({
        status: "fail",
        message: error.message,
      });
    }
  };
};
