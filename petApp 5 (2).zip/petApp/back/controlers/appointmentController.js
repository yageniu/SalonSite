// const fs = require("fs");
const Appointment = require("../models/appointmentModel");

// 1. GET ALL APPOINTMENTS
exports.getAllAppointments = async (req, res) => {
  console.log(req.user);

  try {
    // const appointments = await Appointment.find();

    let appointments;
    if (req.user.role === "admin") {
      appointments = await Appointment.find();
    } else {
      const userId = req.user._id;
      appointments = await Appointment.find({ user: userId });
      // .populate("users");
    }
    res.status(200).json({
      status: "success",
      results: appointments.length,
      data: {
        appointments,
      },
    });
  } catch (err) {
    res.status(404).json({
      status: "fail",
      message: err.message,
    });
  }
};

//2. GET APPOINTMENT BY ID

exports.getAppointmentById = async (req, res) => {
  // console.log(req.params);
  try {
    const { id } = req.params;

    const fappointment = await Appointment.findById(id);
    //tas pats: Appointment.findOne({_id: id});

    res.status(200).json({
      status: "success",
      data: {
        appointment: fappointment,
      },
    });
  } catch (err) {
    res.status(404).json({
      status: "fail",
      message: err.message,
    });
  }
};

// 3. POST appointment
exports.createAppointment = async (req, res) => {
  // console.log(req.body);
  // const newAppointment = new Appointment(req.body);
  // newAppointment.save();

  // grąžina promise
  try {
    const newAppointment = await Appointment.create({
      ...req.body,
      user: req.user._id,
    });
    res.status(201).json({
      status: "success",
      data: { appointment: newAppointment },
    });
  } catch (err) {
    res.status(400).json({
      status: "fail",
      message: err.message,
    });
  }
};

// 4. UPDATE appointment, method patch, užklausa turi body it id
exports.updateAppointment = async (req, res) => {
  try {
    //request body nurodo į ką keičiame, kadangi metodas patch, tai body atsineša ne visą objektą, o tik keičiamus laukus
    const newAppointment = req.body;
    const { id } = req.params;
    const updatedAppointment = await Appointment.findByIdAndUpdate(
      id,
      newAppointment,
      {
        //kad grąžintų atnaujintą dokumentą
        new: true,
        runValidators: true,
      }
    );

    res.status(200).json({
      status: "success",
      data: { appointment: updatedAppointment },
    });
  } catch (err) {
    res.status(400).json({
      status: "fail",
      message: err.message,
    });
  }
};

exports.updateStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const updatedStatus = await Appointment.findByIdAndUpdate(
      id,
      { status: true },
      {
        new: true,
      }
    );
    res.status(200).json({
      status: "success",
      data: {
        appointment: updatedStatus,
        message: "Appointment status updated",
      },
    });
  } catch (err) {
    res.status(400).json({
      status: "fail",
      message: err.message,
    });
  }
};

// 5. DELETE appointment, klientui nesiunčiame jokių duomenų response
exports.deleteAppointment = async (req, res) => {
  try {
    const { id } = req.params;
    await Appointment.findByIdAndDelete(id);

    res.status(204).json({
      status: "success",
      data: null,
    });
  } catch (err) {
    res.status(400).json({
      status: "fail",
      message: err.message,
    });
  }
};
