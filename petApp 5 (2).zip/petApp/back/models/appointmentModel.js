const mongoose = require("mongoose");

const appointmentSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Pet name is required"],
    trim: true,
  },
  owner: {
    type: String,
    required: [true, "Pet owner is required"],

    trim: true,
  },
  date: {
    type: String,
    required: [true, "Date is required"],
    trim: true,
  },
  time: {
    type: String,
    required: [true, "Time is required"],
  },
  note: {
    type: String,
    required: true,
    trim: true,
  },
  
  rating: {
    type: Number,
  },
  status: {
    type: Boolean,
    default: false,
  },
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
});

const Appointment = mongoose.model("Appointment", appointmentSchema);
module.exports = Appointment;
