const moongoose = require("mongoose");
const validator = require("validator");
const bcrypt = require("bcrypt"); // priedas su algoritmais, kurie leis uzhashinti passworda

const userSchema = new moongoose.Schema({
  name: {
    type: String,
    required: [true, "Please enter your name!"],
    trim: true,
  },
  email: {
    type: String,
    required: [true, "Please enter your email!"],
    unique: [true, "Email already exists!"],
    lowercase: true,
    validate: [validator.isEmail, "Please enter a valid email!"],
    trim: true,
  },
  password: {
    type: String,
    required: [true, "Please enter your password!"],
    minlength: [8, "Password should be at least 8 characters long!"],
    select: false, // SVARBU! kad neselect'intu paswordo niekur
  },
  passwordConfirm: {
    type: String,
    required: [true, "Please confirm your password!"],
    validate: {
      // sitas validatorius turi buti KLASIKINE FUNKCIJA visada!
      validator: function (confirmedPass) {
        return confirmedPass === this.password; // returnina true ar false, this.password rodo i schema password objekta
      },
      message: "Passwords do not match!",
    },
  },
  role: {
    type: String,
    enum: ["user", "admin"],
    message: "Role must be either user or admin!",
    default: "user",
  },
});

// midleware schemai, .pre - tai funcija vykstanti pries isaugant useri, reikes uzkriptinti passworda is confirmed passworda nusiusti i undefined
userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next(); // return turi buti, kad nebutu vykdoma toliau funkcija, jei pokyciu nera
  this.password = await bcrypt.hash(this.password, 12);
  this.passwordConfirm = undefined;
  next(); // svarbu, perduodam middle ware i kita f-ja
});

userSchema.methods.correctPassword = async function (
  // patikrinam ar passwordas atitinka su paswordu is DB su tuo, kuri useris veda
  candidatePassword,
  userPassword
) {
  return await bcrypt.compare(candidatePassword, userPassword); // metodas .compare lygina passwordus abu
};

module.exports = moongoose.model("User", userSchema);
