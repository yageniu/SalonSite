const express = require('express');
// const userControler = require("../controlers/userControler");
const authController = require('../controlers/authController');
const { signup, login } = authController; //objektas su sitom funkcijom, del to isdestruktinam, kad pasiimti tas funcijytes


const router = express.Router();


router.route('/signup').post(signup); // signup funkcija gausime is kontrolerio
router.route('/login').post(login); /// login irgi yra post, nešame bodyje duomenis

module.exports = router;