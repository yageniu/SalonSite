const express = require("express");
const appointmentController = require("../controlers/appointmentController");
const authController = require("../controlers/authController");

const {
  getAllAppointments,
  getAppointmentById,
  createAppointment,
  updateAppointment,
  deleteAppointment,
  updateStatus,
  checkID,
} = appointmentController;

// is authController kontrolerio pasiima tik protect ir allowTo funkcija
const { protect, allowTo } = authController;

const appointmentRouter = express.Router();

appointmentRouter.route("/").get(protect, getAllAppointments).post(protect,  createAppointment);
appointmentRouter.route("/:id").get(getAppointmentById).patch(protect, updateAppointment).delete(protect, deleteAppointment);
appointmentRouter.route('/status/:id').patch(protect, allowTo("admin"), updateStatus);

module.exports = appointmentRouter;

//.post(protect, allowTo("admin"), createAppointment);