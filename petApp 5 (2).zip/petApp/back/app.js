// const { log } = require('console');
const express = require('express');
// const fs = require('fs');
const appointmentRouter = require('./routes/appointmentRoutes');
const userRouter = require('./routes/userRoutes');

//cors
const cors = require('cors');
// create server
const app = express();
app.use(cors());

// leidziam uzklausas is fronto tik is sito localhost porto
// app.use (
//   cors({
//     origin: 'http://localhost:5173',
//   })
// )

app.use(express.json()); // be sitos funkcijos body nesimatys, nes body yra json

app.use((req, res, next) => {
  req.requestTime = new Date().toISOString();
  next();
});

app.use('/api/v1/appointments', appointmentRouter);
app.use('/api/v1/users', userRouter);


// app.all("*", (req, res, next) => {})


module.exports = app;
