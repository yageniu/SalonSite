
const fs = require("fs");
const mongoose = require("mongoose");
const Book = require("./models/bookModel");
const { Console } = require("console");
const dotenv = require("dotenv").config(); 

const dbURL = process.env.DATABASE_URL; 

async function main() {
  await mongoose.connect(dbURL); 
  console.log("Connected to database");
}
main().catch((err) => console.log(err.message));


const books = fs.readFileSync("./dev-data/books.json", "utf-8");

const importData = async () => {
  try {
    await Book.create(JSON.parse(books));
    console.log("Data successfully loaded");
    process.exit();
  } catch (err) {
    console.log(err.message);
  }
};


const deleteData = async () => {
  try {
    await Book.deleteMany();
    console.log("Data successfully deleted");
    process.exit();
  } catch (err) {
    console.log(err.message);
  }
};

console.log(process.argv); 

if (process.argv[2] === "--import") {
  importData();
} else if (process.argv[2] === "--delete") {
  deleteData();
}